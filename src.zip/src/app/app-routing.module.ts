import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'folder/Inbox',
    pathMatch: 'full'
  },
  {
    path: 'folder/:id',
    loadChildren: () => import('./folder/folder.module').then( m => m.FolderPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./features/components/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'create-assessment',
    loadChildren: () => import('./features/components/assessments/create-assessment/create-assessment.module').then( m => m.CreateAssessmentPageModule)
  },
  {
    path: 'list-assessment',
    loadChildren: () => import('./features/components/assessments/list-assessment/list-assessment.module').then( m => m.ListAssessmentPageModule)
  },
  {
    path: 'score-card',
    loadChildren: () => import('./features/components/score-card/score-card.module').then( m => m.ScoreCardPageModule)
  },
  {
    path: 'new-comp',
    loadChildren: () => import('./new-comp/new-comp.module').then( m => m.NewCompPageModule)
  },
  {
    path: 'sign-up',
    loadChildren: () => import('./features/components/sign-up/sign-up.module').then( m => m.SignUpPageModule)
  },
  {
    path: 'list-assessments',
    loadChildren: () => import('./features/components/assessments/list-assessment/list-assessment.module').then( m => m.ListAssessmentPageModule)
  },
  {
    path: 'edit-assessment',
    loadChildren: () => import('./features/components/assessments/edit-assessment/edit-assessment.module').then( m => m.EditAssessmentPageModule)
  },
  {
    path: 'details-assessment',
    loadChildren: () => import('./features/components/assessments/details-assessment/details-assessment.module').then( m => m.DetailsAssessmentPageModule)
  },
  {
    path: 'list-assessment',
    loadChildren: () => import('./features/components/assessments/list-assessment/list-assessment.module').then( m => m.ListAssessmentPageModule)
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
