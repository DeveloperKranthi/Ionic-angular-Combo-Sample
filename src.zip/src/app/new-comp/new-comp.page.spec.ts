import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { NewCompPage } from './new-comp.page';

describe('NewCompPage', () => {
  let component: NewCompPage;
  let fixture: ComponentFixture<NewCompPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewCompPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(NewCompPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
