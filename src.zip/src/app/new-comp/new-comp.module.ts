import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { NewCompPageRoutingModule } from './new-comp-routing.module';

import { NewCompPage } from './new-comp.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NewCompPageRoutingModule
  ],
  declarations: [NewCompPage]
})
export class NewCompPageModule {}
