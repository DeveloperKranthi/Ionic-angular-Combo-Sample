import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-comp',
  templateUrl: './new-comp.page.html',
  styleUrls: ['./new-comp.page.scss'],
})
export class NewCompPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
