import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NewCompPage } from './new-comp.page';

const routes: Routes = [
  {
    path: '',
    component: NewCompPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class NewCompPageRoutingModule {}
