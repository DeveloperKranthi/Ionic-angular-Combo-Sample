import { Component, OnInit } from '@angular/core';
import { FormBuilder ,FormGroup , Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})

export class LoginPage implements OnInit{
  LoginForm: FormGroup;

  response = {
    success: true,
    data: {
      firstName: 'Bruce',
      password: 'password',
      OTP: 1234,
      pin: 1111,
      countrId: 4200,
      role: 1,
      active: 12
    }
  };
  constructor(public fb: FormBuilder) {}

  ngOnInit():void {
    this.LoginForm = this.fb.group({
      firstName: ['', [Validators.required]],
      password: [''],
      pin: ['',[Validators.required]]
    })
  }

  onSubmit(data) {
    console.log(data)
    if (this.response.success === true) {
      if (this.response.data.firstName === data.firstName && 
          this.response.data.password === data.password) {
        console.log('Hello', data.firstName);
          console.log('password', data.password);
          console.log('Successfull LoggedIn');
      }
      else {
        console.log('values Doesnt Matching Enter Valid');
      }
    }
    else {
      console.log('Please Enter Valid Username & Pin');
    }
  }
}