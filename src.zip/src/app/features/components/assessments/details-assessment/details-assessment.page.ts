import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-details-assessment",
  templateUrl: "./details-assessment.page.html",
  styleUrls: ["./details-assessment.page.scss"],
})
export class DetailsAssessmentPage implements OnInit {
  Assessments: any = [
    {
      assessmentsName: "UserReview",
      assessmentsID: 1,
      assessmentResponse: [
        { Question: "1 question", answer: "1 answer" },
        { Question: "2 question", answer: "2 answer" },
        { Question: "3 question", answer: "3 answer" },
        { Question: "4 question", answer: "4 answer" },
        { Question: "5 question", answer: "5 answer" },
        { Question: "6 question", answer: "6 answer" },
      ]
    }
  ]

  constructor() {
    
  }

  ngOnInit() {}
}
