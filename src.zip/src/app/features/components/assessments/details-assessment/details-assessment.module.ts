import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DetailsAssessmentPageRoutingModule } from './details-assessment-routing.module';

import { DetailsAssessmentPage } from './details-assessment.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DetailsAssessmentPageRoutingModule
  ],
  declarations: [DetailsAssessmentPage]
})
export class DetailsAssessmentPageModule {}
