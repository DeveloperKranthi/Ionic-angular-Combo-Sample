import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DetailsAssessmentPage } from './details-assessment.page';

const routes: Routes = [
  {
    path: '',
    component: DetailsAssessmentPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DetailsAssessmentPageRoutingModule {}
