import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ListAssessmentPageRoutingModule } from './list-assessment-routing.module';

import { ListAssessmentPage } from './list-assessment.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ListAssessmentPageRoutingModule
  ],
  declarations: [ListAssessmentPage]
})
export class ListAssessmentPageModule {}
