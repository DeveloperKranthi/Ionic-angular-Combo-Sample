import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ListAssessmentPage } from './list-assessment.page';

const routes: Routes = [
  {
    path: '',
    component: ListAssessmentPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ListAssessmentPageRoutingModule {}
