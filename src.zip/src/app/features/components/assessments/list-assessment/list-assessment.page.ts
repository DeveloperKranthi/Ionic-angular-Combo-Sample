import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-list-assessment",
  templateUrl: "./list-assessment.page.html",
  styleUrls: ["./list-assessment.page.scss"],
})
export class ListAssessmentPage implements OnInit {
  // Arrys = [1,2,3,4]
  Assessments : any = [];
  constructor() {
    this.Assessments = [
      {
        assessmentName: "Review :1",
        assessmentID: 1,
        assessmentResponse: { Question: "Company reputation ?", Answer: "GOOD" },
      },
      {
        assessmentName: "Review :2",
        assessmentID: 2,
        assessmentResponse: { Question: "Product based Company ?", Answer: "Yes" },
      },
      {
        assessmentName: "Review :3",
        assessmentID: 3,
        assessmentResponse: { Question: "Good In Market ?", Answer: "yup! Good in Market" },
      },
      {
        assessmentName: "Review :4",
        assessmentID: 4,
        assessmentResponse: { Question: "Best Place to Invest", Answer: "Yes, 100%" },
      },
      {
        assessmentName: "Review :5",
        assessmentID: 5,
        assessmentResponse: { Question: "Deserve 5/5", Answer: "Yes" },
      }
    ];
  }

  ngOnInit() {
    this.getData();
  }

  send(){
    console.log("Kranthi");
  }
  getData() {
    console.log("Welcome to assessment page");
  }
  
}
