import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EditAssessmentPageRoutingModule } from './edit-assessment-routing.module';

import { EditAssessmentPage } from './edit-assessment.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    EditAssessmentPageRoutingModule
  ],
  declarations: [EditAssessmentPage]
})
export class EditAssessmentPageModule {}
