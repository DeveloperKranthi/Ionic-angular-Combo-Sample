import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-assessment',
  templateUrl: './edit-assessment.page.html',
  styleUrls: ['./edit-assessment.page.scss'],
})
export class EditAssessmentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
