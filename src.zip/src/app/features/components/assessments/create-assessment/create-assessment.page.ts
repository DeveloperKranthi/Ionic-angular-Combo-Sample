import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

@Component({
  selector: "app-create-assessment",
  templateUrl: "./create-assessment.page.html",
  styleUrls: ["./create-assessment.page.scss"],
})
export class CreateAssessmentPage implements OnInit {
  createAssessment: FormGroup;
  processID ;
  Countries = [
    { countryId: 1, countryName: "India" },
    { countryId: 2, countryName: "Aus" },
    { countryId: 3, countryName: "Srilanka" },
    { countryId: 4, countryName: "America" },
    { countryId: 5, countryName: "Scottland" },
    { countryId: 6, countryName: "Saudi" },
    { countryId: 7, countryName: "England" },
  ];

  Industries = [
    { industryId: 1, industryName: "SteelFactory", countryId: 1 },
    { industryId: 2, industryName: "FoodFactory", countryId: 2 },
    { industryId: 3, industryName: "IronFactory", countryId: 3 },
    { industryId: 4, industryName: "SteelFactory", countryId: 4 },
    { industryId: 5, industryName: "BiscuitFactory", countryId: 5 },
    { industryId: 6, industryName: "MOTOR-Factory", countryId: 6 },
    { industryId: 7, industryName: "BoatsFactory", countryId: 7 },
  ];

  Organizations = [
    {
      organizationId: 10,
      organizationName: "aaa",
      industryId: 1,
      countryId: 1,
    },
    {
      organizationId: 20,
      organizationName: "bbb",
      industryId: 2,
      countryId: 2,
    },
    {
      organizationId: 30,
      organizationName: "ccc",
      industryId: 3,
      countryId: 3,
    },
    {
      organizationId: 40,
      organizationName: "ddd",
      industryId: 4,
      countryId: 4,
    },
    {
      organizationId: 50,
      organizationName: "eee",
      industryId: 5,
      countryId: 5,
    },
    {
      organizationId: 60,
      organizationName: "fff",
      industryId: 6,
      countryId: 6,
    },
    {
      organizationId: 70,
      organizationName: "ggg",
      industryId: 7,
      countryId: 7,
    },
  ];

  Processes = [
    {
      processId: 11,
      processName: "abc-process",
      industryId: 1,
      countryId: 1,
      organizationId: 10,
    },
    {
      processId: 22,
      processName: "bc-process",
      industryId: 2,
      countryId: 2,
      organizationId: 20,
    },
    {
      processId: 33,
      processName: "ac-process",
      industryId: 3,
      countryId: 3,
      organizationId: 30,
    },
    {
      processId: 44,
      processName: "cc-process",
      industryId: 4,
      countryId: 4,
      organizationId: 40,
    },
    {
      processId: 55,
      processName: "sc-process",
      industryId: 5,
      countryId: 5,
      organizationId: 50,
    },
    {
      processId: 66,
      processName: "gc-process",
      industryId: 6,
      countryId: 6,
      organizationId: 60,
    },
    {
      processId: 77,
      processName: "hc-process",
      industryId: 7,
      countryId: 7,
      organizationId: 70,
    },
  ];

  AllQuestion = {
    11: [
      { Question: "first Question ?", Answer: "Pass" },
      { Question: "second Question ?", Answer: "skip" },
    ],
    22: [
      { Question: "2 first Question ?", Answer: "Pass" },
      { Question: "2 second Question ?", Answer: "skip" },
    ],
    33: [
      { Question: "3 first Question ?", Answer: "Pass" },
      { Question: "3 second Question ?", Answer: "skip" },
    ],
    44: [
      { Question: "4 first Question ?", Answer: "Pass" },
      { Question: "4 second Question ?", Answer: "skip" },
    ],
    55: [
      { Question: "5 first Question ?", Answer: "Pass" },
      { Question: "5 second Question ?", Answer: "skip" },
    ],
    66: [
      { Question: "6 first Question ?", Answer: "Pass" },
      { Question: "6 second Question ?", Answer: "skip" },
    ],
    77: [
      { Question: "7 first Question ?", Answer: "Pass" },
      { Question: "7 second Question ?", Answer: "skip" },
    ]
  };

  ObjData: {
    person0:  [{first: 1, second:2},{first: 1, second:2}],
    person1: [{first: 1, second:2},{first: 1, second:2}],
    person2: [{first: 1, second:2},{first: 1, second:2}],
  }


  constructor(public fb: FormBuilder) {}

  ngOnInit() {
    this.createAssessment = this.fb.group({
      countryId: ["", [Validators.required]],
      industryId: ["", [Validators.required]],
      organizationId: ["", [Validators.required]],
      processId: ["", [Validators.required]],
    });
  }

  OnSubmit(data) {
    console.log(data);
    console.log(data.processId);
  }

  getProcessId(processid) {
    console.log(this.AllQuestion)
    console.log(processid);
    this.processID = processid;
    
  }
}
