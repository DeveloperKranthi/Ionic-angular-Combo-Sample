import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreateAssessmentPageRoutingModule } from './create-assessment-routing.module';

import { CreateAssessmentPage } from './create-assessment.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreateAssessmentPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [CreateAssessmentPage]
})
export class CreateAssessmentPageModule {}
