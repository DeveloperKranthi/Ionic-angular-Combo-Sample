import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CreateAssessmentPage } from './create-assessment.page';

const routes: Routes = [
  {
    path: '',
    component: CreateAssessmentPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CreateAssessmentPageRoutingModule {}
