import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.page.html',
  styleUrls: ['./sign-up.page.scss'],
})
export class SignUpPage implements OnInit {
  SignUpForm: FormGroup;

  response = {
    success: true,
    data: {
      firstName: 'Bruce',
      lastName: 'Wan',
      Email: '',
      password: 'password',
      otp: 1234,
      pin: 1111
    }
  };
  constructor(public fb: FormBuilder) {}

  ngOnInit():void {
    this.SignUpForm = this.fb.group({
      firstName: ['', [Validators.required]],
      lastName: [''],
      Email: ['', [Validators.required]],
      password: [''],
      otp: [''],
      pin: ['',[Validators.required]]
    })
  }

  onSubmit(data) {
    console.log(data);
    
    console.log(data)
    if (this.response.success === true) {
      if (this.response.data.firstName === data.firstName && 
          this.response.data.password === data.password) {
        console.log('Hello', data.firstName);
          console.log('password', data.password);
          console.log('Successfull LoggedIn');
      }
      else {
        console.log('values Doesnt Matching Enter Valid');
      }
    }
    else {
      console.log('Please Enter Valid Username & Pin');
    }
  }
}
